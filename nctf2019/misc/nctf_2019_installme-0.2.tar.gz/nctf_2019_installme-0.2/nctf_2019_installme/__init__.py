def get_flag():
    return 'Believe it or not. Flag is already in your machine. Can you find it?'
