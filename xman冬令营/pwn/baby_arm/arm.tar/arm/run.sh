qemu-arm -g 1234 -L /usr/arm-linux-gnueabihf ./pwn
