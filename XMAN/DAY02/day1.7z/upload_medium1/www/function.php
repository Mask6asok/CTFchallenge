<?php
function C4es4r($data, $num){
    $re = '';
    for ($x=0; $x<strlen($data); $x++){
        if ($data[$x]>='A' && $data[$x]<='Z'){
            $tmp = ord($data[$x]) + $num;
            if ($tmp > ord('Z')){
                $tmp -= 26;
            }
            $re .= chr($tmp);
        }
        elseif ($data[$x]>='a' && $data[$x]<='z'){
            $tmp =  ord($data[$x]) - $num;
            if ($tmp < ord('a')){
                $tmp += 26;
            }
            $re .= chr($tmp);
        }
        else{
            $re .= $data[$x];
        }
    }
    return $re;
}
function unC4es4r($data, $num){
    $re = '';
    for ($x=0; $x<strlen($data); $x++){
        if ($data[$x]>='A' && $data[$x]<='Z'){
            $tmp = ord($data[$x]) - $num;
            if ($tmp < ord('A')){
                $tmp += 26;
            }
            $re .= chr($tmp);
        }
        elseif ($data[$x]>='a' && $data[$x]<='z'){
            $tmp =  ord($data[$x]) + $num;
            if ($tmp > ord('z')){
                $tmp -= 26;
            }
            $re .= chr($tmp);
        }
        else{
            $re .= $data[$x];
        }
    }
    return $re;
}

// $a = 'Av335BGEgeag3525!@d';
// echo $a.'</br>';
// $r = C4es4r($a, 6);
// echo $r.'</br>';
// echo unC4es4r($r, 6);
?>