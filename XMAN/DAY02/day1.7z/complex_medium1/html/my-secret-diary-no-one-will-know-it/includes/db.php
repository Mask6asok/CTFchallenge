<?php
$db = new PDO('mysql:host=localhost;dbname=diary;charset=utf8mb4', 'user', 'userpassword');
