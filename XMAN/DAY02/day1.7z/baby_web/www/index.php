<?php
header('FLAG: flag{very_baby_web}');
header("Location: https://rois.io");
?>
Flag is hidden!