<?php
require 'includes/db.php';

$id = $_GET['id'] ?? '0';
if (preg_match('/AND|OR|\||\&|\^/i', $id)) {
	exit('Hacker');
}
$ret = $db->exec('SELECT * FROM users WHERE id = ' . $id);
// select ? from flag
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<?php show_source(__FILE__);?>
</body>
</html>