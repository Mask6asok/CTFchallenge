<?php
$db = new PDO('mysql:host=mysql;dbname=jail-password;charset=utf8mb4', 'root', 'justAUselessPasswordAAAAAA');
