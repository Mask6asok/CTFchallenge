hello-world-lamp
================

Hello world in PHP to test LAMP deployments
