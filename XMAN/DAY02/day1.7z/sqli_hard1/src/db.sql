use ctftraining;

CREATE TABLE passage
(
    id int PRIMARY KEY AUTO_INCREMENT,
    content varchar(1000)
);


INSERT INTO passage values(NULL, 'this is the first passage '),(NULL, 'this is passage 2')
